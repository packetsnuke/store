<div class="form-group row">
	<label class="col-sm-3 control-label"><?php echo $addons->__('addon_setting_show_languages'); ?></label>
	<div class="col-sm-6">
		<?php echo displayRadio('show_languages', $data['settings'], 'show_languages', 1); ?>		
	</div>				
</div>