﻿<div class="row">
	<div class="col-md-12">
		<div class="alert alert-danger" role="alert"><strong>You missing add API or Your API not actived.</strong></div>
		<p>Pleae go to <a href="<?php echo site_url('index.php/settings'); ?>"><strong>Settings</strong></a> > Tab <strong>Config</strong> and check setting store.</p>
	</div>
</div>