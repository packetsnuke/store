<div class="footer clearfix">
	<div class="footer-inner">
		&copy; <a href="https://tshirtecommerce.com/" target="_blank">tshirtecommerce.com</a>
	</div>
	<div class="footer-items">
		<span class="go-top"><i class="clip-chevron-up"></i></span>
	</div>
</div>

<script type="text/javascript">
	var admin_url_site = '<?php echo site_url(''); ?>';
	jQuery(document).ready(function(){
		Main.init();
		if(typeof window.parent.setHeightF != 'undefined')
		{
			var height = jQuery('body').height();
			window.parent.setHeightF(height);
		}
	});
</script>			
	</body>
</html>