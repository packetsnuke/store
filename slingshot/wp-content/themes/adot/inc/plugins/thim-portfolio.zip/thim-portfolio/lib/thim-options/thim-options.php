<?php
if (!class_exists('THIM_Option')) {
	/**
	 * Thim Theme
	 *
	 * Manage Option in the THIM Framework
	 *
	 * @class THIM_Option
	 * @package thimpress
	 * @since 1.0
	 * @author kien16
	 */
	class THIM_Option
	{
		/**
		 * @var array option information
		 */
		public $option;

		public $data;

		public $output;

		public static $added_script_bg_image = false;

		// Safe to start up
		public function __construct($args)
		{
			$this->option = $this->register_settings($args);
			// Assign meta box values to local variables and add it's missed values

			if (isset($_REQUEST['post_type']) && $_REQUEST['post_type'] == 'portfolio' && isset($_REQUEST['page']) && $_REQUEST['page'] == 'init.php') {
				$this->output = $this->display_setting($this->option);
			}
		}

		/**
		 * Register settings
		 *
		 * @since 1.0
		 */
		public function register_settings($args)
		{

			foreach ($args as $id => $setting) {
				$option[] = $this->create_setting($setting);
			}
			return $option;

		}

		/**
		 * Create settings field
		 *
		 * @since 1.0
		 */
		public function create_setting($args = array())
		{

			// Set default values for meta box
			$option = wp_parse_args($args, array(
				'id' => 'default_field',
				'name' => __('Default Field', 'thimpress'),
				'desc' => __(''),
				'std' => '',
				'type' => 'text',
				'options' => array(),
				'class' => ''
			));
			return $option;
		}

		/**
		 * HTML output for text field
		 *
		 * @since 1.0
		 */
		public function display_setting($args = array())
		{
			if (!get_option(THIM_PORTFOLIO_OPTION)) {
				$this->initialize_settings();
			}
			$options_data = get_option(THIM_PORTFOLIO_OPTION);

			$this->data = $options_data;

			$output = "";
			foreach ($args as $value) {
				switch ($value['type']) {

					case 'heading':
						$output .= '<div class="heading">';
						$output .= '<h3>' . $value['name'] . '</h3>';
						$output .= '<div class="description">' . $value['desc'] . '</div>';
						$output .= '</div>';

						break;
					case 'checkbox':
						if (isset($options_data[$value['id']])) {
							$cb = $options_data[$value['id']];
						} else if (isset($value['std'])) {
							$cb = $value['std'];
						} else {
							$cb = 0;
						}
						$output .= '<label class="title" for="' . $value['id'] . '">' . $value['name'] . '</label>';
						$output .= '<input type="checkbox" class="checkbox of-input" name="' . $value['id'] . '" id="' . $value['id'] . '" value="1" ' . checked($cb, 1, false) . ' />';
						$output .= '<div class="description">' . $value['desc'] . '</div>';

						break;
					case 'select':
						if (isset($options_data[$value['id']])) {
							$sl = $options_data[$value['id']];
						} else if (isset($value['std'])) {
							$sl = $value['std'];
						} else {
							$sl = "";
						}

						$output .= '<div class="select_wrapper">';
						$output .= '<label class="title" for="' . $value['id'] . '">' . $value['name'] . '</label>';
						$output .= '<select class="select of-input" name="' . $value['id'] . '" id="' . $value['id'] . '">';

						foreach ($value['options'] as $select_ID => $option) {
							$theValue = $option;
							if (!is_numeric($select_ID)) {
								$theValue = $select_ID;
							}
							$output .= '<option id="' . $select_ID . '" value="' . $theValue . '" ' . selected($sl, $theValue, false) . ' />' . $option . '</option>';
						}
						$output .= '</select>';
						$output .= '<div class="description">' . $value['desc'] . '</div>';
						$output .= '</div>';

						break;

					case 'radio':
						if (isset($options_data[$value['id']])) {
							$ra = $options_data[$value['id']];
						} else if (isset($value['std'])) {
							$ra = $value['std'];
						} else {
							$ra = "";
						}

						$i = 0;
						$output .= '<label class="title" for="' . $value['id'] . '">' . $value['name'] . '</label>';
						foreach ($value['options'] as $v => $label) {
							$output .= '<input class="radio" type="radio" name="' . $value['id'] . '" id="' . $value['id'] . $i . '" value="' . esc_attr($v) . '" ' . checked($ra, $v, false) . '> <label for="' . $value['id'] . $i . '">' . $label . '</label>';
							$i++;
						}
						$output .= '<div class="description">' . $value['desc'] . '</div>';

						break;
					case 'radioimage':

						if (isset($options_data[$value['id']])) {
							$ri_value = $options_data[$value['id']];
						} else {
							$ri_value = $value['std'];
						}

						$output .= '<div class="radio-image">';
						$output .= '<label class="title" for="' . $value['id'] . '">' . $value['name'] . '</label>';
						$i = 0;
						foreach ($value['options'] as $key => $option) {
							$i++;

							$checked = '';
							$selected = '';
							if (NULL != checked($ri_value, $key, false)) {
								$checked = checked($ri_value, $key, false);
								$selected = 'of-radio-img-selected';
							}
							$image_thumb_index = strrpos($option, '.', -1);
							$image_thumb = $option;//substr_replace($option, '_thumb', $image_thumb_index, 0);
							$output .= '<div class="image-box">';
							$output .= '<span>';
							$output .= '<input type="radio" id="of-radio-img-' . $value['id'] . $i . '" class="checkbox of-radio-img-radio" value="' . $key . '" name="' . $value['id'] . '" ' . $checked . ' />';
							$output .= '<img src="' . $image_thumb . '" alt="" class="of-radio-img-img-header ' . $selected . '" onClick="document.getElementById(\'of-radio-img-' . $value['id'] . $i . '\').checked = true;" rel-data="' . (($i - 1) % 6) . '"/>';
							$output .= '</span>';
							$output .= '</div>';
						}
						$output .= '<div class="description">' . $value['desc'] . '</div>';
						$output .= '</div>';

						break;
					case 'textarea':
						if (isset($options_data[$value['id']])) {
							$ta = $options_data[$value['id']];
						} else if (isset($value['std'])) {
							$ta = $value['std'];
						} else {
							$ta = "";
						}

						$ta_value = stripslashes($ta);
						$output .= '<label class="title" for="' . $value['id'] . '">' . $value['name'] . '</label>';
						$output .= '<textarea class="of-input" name="' . $value['id'] . '" id="' . $value['id'] . '" cols="' . $cols . '" rows="8">' . $ta_value . '</textarea>';
						$output .= '<div class="description">' . $value['desc'] . '</div>';

						break;
					case 'number':
						$output .= '<div>';
						$output .= '<label class="title" for="' . $value['id'] . '">' . $value['name'] . '</label>';
						$output .= '<input type="number" id="' . $value['id'] . '" name="' . $value['id'] . '" value="' . ($options_data[$value['id']] ? $options_data[$value['id']] : $value['std']) . '" />';
						$output .= '<div class="description">' . $value['desc'] . '</div>';
						$output .= '</div>';
						break;

					case 'text':
						$output .= '<div>';
						$output .= '<label class="title" for="' . $value['id'] . '">' . $value['name'] . '</label>';
						$output .= '<input type="text" id="' . $value['id'] . '" name="' . $value['id'] . '" value="' . ($options_data[$value['id']] ? $options_data[$value['id']] : $value['std']) . '" />';
						$output .= '<div class="description">' . $value['desc'] . '</div>';
						$output .= '</div>';
						break;

					case 'image':
						$output .= $this->image($value, (isset($options_data[$value['id']]) ? $options_data[$value['id']] : $value['std']));
						break;

					case 'color-opacity':
						$output .= $this->colorOpacity($value, (isset($options_data[$value['id']]) ? $options_data[$value['id']] : $value['std']));
						break;

					case 'dimensions':
						$output .= $this->dimensions($value, (isset($options_data[$value['id']]) ? $options_data[$value['id']] : ''));
						break;
					default:
						$output .= '<div>';
						$output .= '<label class="title" for="' . $value['id'] . '">' . $value['name'] . '</label>';
						$output .= '<input type="text" id="' . $value['id'] . '" name="' . $value['id'] . '" value="' . ($options_data[$value['id']] ? $options_data[$value['id']] : $value['std']) . '" />';
						$output .= '<div class="description">' . $value['desc'] . '</div>';
						$output .= '</div>';

						break;
				}
			}
			return $output;
		}

		/**
		 * Initialize settings to their default values
		 *
		 * @since 1.0
		 */
		public function initialize_settings()
		{
			$default_settings = array();
			foreach ($this->option as $id => $setting) {

				if ($setting['type'] != 'heading')
					$default_settings[$setting['id']] = $setting['std'];
			}

			update_option(THIM_PORTFOLIO_OPTION, $default_settings);

		}

		private function image($field, $value)
		{
			// Make sure scripts for new media uploader in WordPress 3.5 is enqueued
			wp_enqueue_media();
			$reorder_nonce = wp_create_nonce("thim-reorder-images_{$field['id']}");
			$delete_nonce = wp_create_nonce("thim-delete-file_{$field['id']}");
			ob_start();
			echo '<div>';
			echo '<div class="title"><label>' . $field['name'] . '</label></div>';
			echo '<div>';
			$image = $value;
			$style = $image ? '' : ' style="display:none;"';
			$img_url = wp_get_attachment_image_src($image, 'thumbnail');
			$link = get_edit_post_link($image);
			echo '
				<div class="' . $field['id'] . '_image_bar" ' . $style . '>
					<img id="' . $field['id'] . '_thumb" width="200" src="' . $img_url[0] . '" />
					<input type="hidden" value="' . esc_html($value) . '" id="' . $field['id'] . '" name="' . $field['id'] . '" />
					<div class="thim-image-bar">
						<a title="Delete" class="thim-delete-file" href="javascript:remove_selected_media(\'' . $field['id'] . '\')" data-attachment_id="' . $image . '">' . __('Remove', 'thimpress') . '</a>
					</div>
				</div>
			';
			$attach_nonce = wp_create_nonce("thim-attach-media_" . $field['id']);
			echo '<a href="javascript:open_media_browser(\'' . $field['id'] . '\');void(0);"  class="button thim-image-advanced-upload hide-if-no-js new-files">' . __('Select or Upload Images', 'thimpress') . '</a>';
			echo '<div class="desc">' . $field['desc'] . '</div>';
			echo '</div>';
			echo '</div>';
			$output = ob_get_clean();
			return $output;
		}

		private function colorOpacity($field, $value)
		{
			wp_enqueue_script('wp-color-picker');
			wp_enqueue_style('wp-color-picker');
			$output = '<div>';
			$output .= '<label class="title" for="' . $field['id'] . '">' . $field['name'] . '</label>';
			$output .= '<input class="tf-colorpicker" type="text" id="' . esc_attr($field['id']) . '" name="' . esc_attr($field['id']) . '" value="' . esc_attr($value) . '" />';
			$output .= '<div class="description">' . esc_html($field['desc']) . '</div>';
			$output .= '</div>';
			return $output;
		}

		private function dimensions($field, $value)
		{
			$options = $field['options'];
			$output = '<div>';
			$output .= '	<label class="title" for="' . $field['id'] . '">' . $field['name'] . '</label>';
			$output .= '	<div>';
			foreach ($options as $key => $option) {
				$opt_value = isset($value[$key]) ? $value[$key] : $option['default'];
				$output .= $option['label'] . '<input size="20px" type="text" id="' . esc_attr($field['id']) . '_' . $key . '" name="' . esc_attr($field['id']) . '[' . $key . ']" value="' . esc_attr($opt_value) . '" />';
			}
			$output .= '	</div>';
			$output .= '	<div class="description">' . esc_html($field['desc']) . '</div>';
			$output .= '</div>';
			return $output;
		}
	}
}