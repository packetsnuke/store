<?php

// Im lang la ko noi gi