( function ( $ ) {

    $( window ).load( function () {
        $( 'input[name="variation_id"]' ).change( function () {
            var pv_id = parseInt( $( this ).val() );
            $( '.ob_product_avariable_detail' ).slideUp();
            if ( pv_id ) {
                $( '.ob_product_detail_' + pv_id ).slideDown();
            }
        } );
    } );

    $.fn.woosalescountdown = function () {
        var countdowns = this;

        for ( var i = 0; i < countdowns.length; i++ ) {
            var _countdown = $( countdowns[i] ),
                    speed = _countdown.attr( 'data-speed' ),
                    // gmt = _countdown.attr( 'data-gmt' ),
                    time = _countdown.attr( 'data-time' ),
                    showtext = _countdown.attr( 'data-showtext' )
            expiryDate = new Date( time ),
                    gmt = -expiryDate.getTimezoneOffset() / 60;

            var options = {
                expiryDate: expiryDate,
                speed: speed ? speed : 500,
                gmt: parseFloat( gmt ),
                showText: parseInt( showtext ),
                localization: woosalescountdown_i18n.localization
            };
            _countdown.mbComingsoon( options );
        }
    }

    $( document ).ready( function () {
        $( '.woosales-counter' ).woosalescountdown();
    } );

} )( jQuery );