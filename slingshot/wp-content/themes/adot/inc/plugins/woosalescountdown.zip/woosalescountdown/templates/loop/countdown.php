<?php
if ( !defined( 'ABSPATH' ) ) {
    exit();
}

global $product;
if ( !$enabled || woosale_get_product_hide_only_countdown($product) === 'yes' ) {
    return;
}

$time = false;
if ( $item['woosale_start'] && $item['current_time'] < $item['woosale_start'] ) {
    $time = $item['woosale_start'];
} else if ( $item['woosale_end'] && $item['woosale_end'] > $item['current_time'] ) {
    $time = $item['woosale_end'];
}

if ( !$time ) {
    return;
}
$date = new DateTime( date( 'Y-m-d H:i:s', $time ), new DateTimeZone( woosales_get_timezone_string() ) );
?>

<div class="myCounter woosales-counter widget_product_detail" data-time="<?php echo esc_attr( $date->format( DATE_ATOM ) ) ?>" data-speed="500" data-showtext="<?php echo esc_attr( $item['hide_datetext'] ) ?>"></div>
